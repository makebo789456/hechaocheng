<?php
/**
 * 登陆
 *
 * @since 2011-01-14
 * @copyright http://www.114la.com
 */
!defined('PATH_ADMIN') && exit('Forbidden');

class ctl_114la_union
{
	public static function index()
	{
        app_tpl::display('114la_union.tpl');
	}
}
?>
