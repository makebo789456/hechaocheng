<?php

define ( 'APP_SEARCH_APPID', '200813321484519616' );
define ( 'APP_SEARCH_HOST', 's.phpwind.com' );


