INSERT INTO `pw_windid_config` (`name`, `namespace`, `value`, `vtype`, `descrip`) VALUES
('security.username.min', 'reg', '3', 'string', ''),
('security.username.max', 'reg', '15', 'string', ''),
('security.password.min', 'reg', '6', 'string', ''),
('security.password.max', 'reg', '15', 'string', ''),
('credits', 'credit', 'a:6:{i:1;a:4:{s:4:"name";s:6:"铜币";s:4:"unit";s:3:"枚";s:4:"open";s:1:"1";s:3:"log";s:1:"1";}i:2;a:4:{s:4:"name";s:6:"威望";s:4:"unit";s:3:"点";s:4:"open";s:1:"1";s:3:"log";s:1:"1";}i:3;a:4:{s:4:"name";s:6:"银元";s:4:"unit";s:3:"个";s:4:"open";s:1:"1";s:3:"log";s:1:"1";}i:4;a:2:{s:4:"name";s:6:"贡献";s:4:"unit";s:3:"点";}i:5;a:2:{s:4:"name";s:6:"鸡蛋";s:4:"unit";s:3:"个";}i:6;a:2:{s:4:"name";s:6:"鲜花";s:4:"unit";s:3:"朵";}}', 'array', '');
