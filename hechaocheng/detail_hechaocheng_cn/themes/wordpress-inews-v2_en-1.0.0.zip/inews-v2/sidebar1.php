<?php if(is_page()) { ?>
<h2>Page navigation</h2><ul class="pagelist">
<?php wp_list_pages('title_li=&depth=1&sort_column=id' ); ?>
</ul>

<h4>Quick Search</h4>
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
<?php } else { ?>

<h4>Quick Search</h4>
<?php include (TEMPLATEPATH . '/searchform.php'); ?>

<h2>Hot Tags</h2>
<?php wp_tag_cloud('smallest=12&largest=12&unit=px&number=15&format=list&orderby=count&order=DESC'); ?>

<h3>Page navigation</h3><ul class="pagelist">
<?php wp_list_pages('title_li=&depth=1&sort_column=id' ); ?>
</ul>

<h3>Historical articles</h3><ul>
<?php wp_get_archives('type=monthly'); ?>
</ul>
<?php }?>

<h3>Link</h3><ul>
<?php get_links(2, '<li>', '</li>', '', TRUE, 'id', FALSE); ?>
</ul>