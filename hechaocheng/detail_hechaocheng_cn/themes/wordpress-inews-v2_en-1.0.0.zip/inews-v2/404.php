<?php get_header(); ?>
<div id="page" class="clearfloat">

<div id="center">
<div class="col">
<div class="post">
<h2>No respite</h2>
<center><br/>Sorry!The page you browse Nothing.<br/><br/>May the pages are being prepared<br/><br/>May have been renamed or migration<br/><br/>May also be the page that did not exist before.<br/><br/><br/>You can<a href="<?php echo get_option('home'); ?>/">Back Home</a>,Or try the Search:<br/><br/>
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
</center></div><!--END POST-->
</div><!--END COL-->
</div><!--END CENTER-->

<div id="left"><!--左侧开始-->
<?php include (TEMPLATEPATH . '/sidebar1.php'); ?>
</div><!--左侧结束-->

<div id="right"><!--右侧开始-->
<?php include (TEMPLATEPATH . '/sidebar2.php'); ?>
</div><!--右侧结束-->

</div><!--END PAGE-->
<?php get_footer(); ?>