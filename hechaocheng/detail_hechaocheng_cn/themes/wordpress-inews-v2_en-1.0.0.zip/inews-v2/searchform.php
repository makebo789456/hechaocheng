<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
<input type="text" name="s" id="s" class="input" value="Search..." onBlur="if(this.value=='') this.value='Search...';" onFocus="if(this.value=='Search...') this.value='';" hechaocheng="1" />
<input name="submit" type="submit" class="button" id="searchsubmit" value="Search" />
</form>
