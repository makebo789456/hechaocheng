<?php get_header(); ?>
<div id="page" class="clearfloat">
<div id="center">

<div class="col">
<?php if (have_posts()) : ?>
<?php $post = $posts[0]; // Hack. Set $post so that the_date() works. ?>
<?php /* If this is a category archive */ if (is_category()) { ?>
<h2 class="pagetitle">[<?php single_cat_title(); ?>]Article Category</h2>
<?php /* If this is a tag archive */ } elseif( is_tag() ) { ?>
<h2 class="pagetitle">[<?php single_tag_title(); ?>]Label articles</h2>
<?php /* If this is a daily archive */ } elseif (is_day()) { ?>
<h2 class="pagetitle">[<?php the_time('Y-m-d') ?>]Today article</h2>
<?php /* If this is a monthly archive */ } elseif (is_month()) { ?>
<h2 class="pagetitle">[<?php the_time('Y-m') ?>]Month article</h2>
<?php /* If this is a yearly archive */ } elseif (is_year()) { ?>
<h2 class="pagetitle">[<?php the_time('Y') ?>]Full article</h2>
<?php /* If this is an author archive */ } elseif (is_author()) { ?>
<h2 class="pagetitle">Author Archive</h2>
<?php /* If this is a paged archive */ } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
<h2 class="pagetitle">Blog Archives</h2>
<?php } ?>

<?php while (have_posts()) : the_post(); ?>
<div class="postlist" id="post-<?php the_ID(); ?>"><h4><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a><span><a href="<?php the_permalink() ?>">Read more&raquo;</a></span></h4>
<div class="postcontent"><?php the_excerpt(); ?></div><div class="postmeat al">Date:<?php the_time('Y-m-d') ?>  | Classification：<?php the_category(', ') ?></div>
</div>
<?php endwhile; ?>

<div class="navigation clearfloat">
<div class="fr"><?php next_posts_link('Next &raquo;') ?></div>
<div class="fl"><?php previous_posts_link('&laquo; Previous') ?></div>
</div>

<?php else : ?>
<div class="post">
<h2>No respite</h2>
<center><br/>Sorry!The page you browse Nothing.<br/><br/>Might pages are being prepared.<br/><br/>May have been renamed or migration.<br/><br/>May the page did not exist before.<br/><br/><br/>You can<a href="<?php echo get_option('home'); ?>/">Back Home</a>,Or try the Searc:<br/><br/>
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
</center></div><!--END POST-->

<?php endif; ?>
</div><!--END COL-->
</div><!--END CENTER-->

<div id="left"><!--左侧开始-->
<?php include (TEMPLATEPATH . '/sidebar1.php'); ?>
</div><!--左侧结束-->

<div id="right"><!--右侧开始-->
<?php include (TEMPLATEPATH . '/sidebar2.php'); ?>
</div><!--右侧结束-->

</div><!--END PAGE-->
<?php get_footer(); ?>