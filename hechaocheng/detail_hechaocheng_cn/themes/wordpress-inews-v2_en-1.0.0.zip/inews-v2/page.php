<?php get_header(); ?>
<div id="page" class="clearfloat">
<div id="center2">

<div class="col">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="post" id="post-<?php the_ID(); ?>">
<h2><?php the_title(); ?></h2>
<div class="postmeat ac"><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a> &nbsp; <?php the_time('Y-m-d G:i') ?> &nbsp; <a href="#respond" title="Comments welcome">Comments&raquo;</a> &nbsp; <?php edit_post_link('(Edit)', '', ''); ?></div>
<div class="entry">
<?php the_content('<p class="serif">Read the rest of this page &raquo;</p>'); ?>
<?php wp_link_pages(array('before' => '<p><strong>Pages:</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
</div><!--END ENTRY-->
<div class="postfooter">
<div>Author:<a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a> &nbsp; <?php the_author_posts_link() ?></div>
<div>Link address:<a href="<?php the_permalink() ?>"><?php the_permalink() ?></a></div>
<div>Last updated:<?php the_modified_time('Y-m-d G:i'); ?></div>
<div>Copyright: without the permission of this article prohibited reproduced or mirror or copy to use in any other way.</div>
</div><!--END POSTFOOTER-->
<?php comments_template(); ?>
</div><!--END POST-->

<?php endwhile; else: ?>
<div class="post">
<h2>No respite.</h2>
<center><br/>Sorry!The page you browse Nothing.<br/><br/>May the pages are being prepared ...<br/><br/>May have been renamed or migration...<br/><br/>May also be the page that did not exist before...<br/><br/><br/>You can<a href="<?php echo get_option('home'); ?>/">bank home</a>,Or try the search:<br/><br/>
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
</center></div><!--END POST-->

<?php endif; ?>
</div><!--END COL-->
</div><!--END CENTER-->

<div id="left"><!--左侧开始-->
<?php include (TEMPLATEPATH . '/sidebar1.php'); ?>
</div><!--左侧结束-->

<div id="right"><!--右侧开始-->
<?php include (TEMPLATEPATH . '/sidebar2.php'); ?>
</div><!--右侧结束-->

</div><!--END PAGE-->
<?php get_footer(); ?>