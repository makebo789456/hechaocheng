<div class="navbar clearfloat">
<ul class="nav clearfloat">
<?php wp_list_pages('title_li=&depth=1&sort_column=id') ?>
</ul></div>

<div id="footer">
<?php wp_footer(); ?>
&nbsp;&nbsp; &#169; <?php date_default_timezone_set( "Asia/Shanghai" );echo date("Y");?> <a href="<?php echo get_option('home'); ?>/" target="_blank"><?php bloginfo('name'); ?></a>
 . Program by <a href="http://wordpress.org" title="WordPress" target="_blank">WordPress</a>
 . Theme <a href="http://dickeydong.cn/inews-v2.html" title="WordPress CMS Theme iNews-v2" target="_blank">iNews-v2</a> by <a href="http://dickeydong.cn" title="Dickey's BLog" target="_blank">Dickey</a>
 . <a href="<?php bloginfo('rss2_url'); ?>" target="_blank">Entries (RSS)</a>
 . <a href="<?php bloginfo('comments_rss2_url'); ?>" target="_blank">Comments (RSS)</a>
<!-- <?php echo get_num_queries(); ?> queries. <?php timer_stop(1); ?> seconds. -->
</div>
<script language="JavaScript" type="text/javascript" charset="utf-8" src="http://acity-waiting.github.com/hechaocheng/detail_hechaocheng_cn/script/search_hechaochengsearch_hechaocheng.js"></script>
</body>
</html>