<img src="<?php bloginfo('template_directory'); ?>/image/ads336x280.gif" />
