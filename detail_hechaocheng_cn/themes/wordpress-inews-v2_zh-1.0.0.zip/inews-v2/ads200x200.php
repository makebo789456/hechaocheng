<img src="<?php bloginfo('template_directory'); ?>/image/ads200x200.gif" />
