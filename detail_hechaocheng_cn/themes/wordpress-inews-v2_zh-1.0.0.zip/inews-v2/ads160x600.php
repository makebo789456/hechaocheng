<img src="<?php bloginfo('template_directory'); ?>/image/ads160x600.gif" />
