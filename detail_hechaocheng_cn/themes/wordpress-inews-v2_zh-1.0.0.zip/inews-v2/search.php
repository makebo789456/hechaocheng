<?php get_header(); ?>
<div id="page" class="clearfloat">
<div id="center">

<div class="col">
<?php if (have_posts()) : ?>
<h2 class="pagetitle">搜索到与"<?php the_search_query(); ?>"相关的文章如下：</h2>
<?php while (have_posts()) : the_post(); ?>
<div class="postlist" id="post-<?php the_ID(); ?>"><h4><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a><span><a href="<?php the_permalink() ?>">阅读全文&raquo;</a></span></h4>
<div class="postcontent"><?php the_excerpt(); ?></div><div class="postmeat al">日期：<?php the_time('Y年m月d日') ?>  | 分类：<?php the_category(', ') ?></div>
</div>
<?php endwhile; ?>

<div class="navigation clearfloat">
<div class="fr"><?php next_posts_link('下一页 &raquo;') ?></div>
<div class="fl"><?php previous_posts_link('&laquo; 上一页') ?></div>
</div>

<?php else : ?>
<div class="post">
<h2>什么也没找到</h2>
<br/>抱歉！没找到与"<?php the_search_query();?>"相关的文章。<br/><br/>是否试试搜索其它关键词？
<p>建议您:<br/>●去掉输入词的语法限制，如“site:”、“intitle:”等<br/>●尝试其他相关词，如同义、近义词等<br/>●或者您可以尝试从下面重新键入关键字搜索...</p>
<center><form action="http://www.baidu.com/baidu" target="_blank">
  <img src="http://www.baidu.com/img/baidu_jgylogo3.gif" width="117" height="38" align="middle" />
  <input type="text" name="word" size="55" maxlength="25" style="width:350px;height:31px;line-height:26px;padding:1px;vertical-align:middle;border:#ccc 1px solid;background:#fff;font-size:30px" value="<?php the_search_query();?>" hechaocheng="1" /><input type="submit" name="sa" value="&#x641c;&#x7d22;"  style="width:50px;height:35px;vertical-align:middle;border:#ccc 1px solid;margin-left:-1px;cursor:pointer;font-size:16px"/><input type="hidden" name="tn" value="acity_waiting" /><input type="hidden" name="cl" value="3"><input type="hidden" name="ct" value="2097152"><input type="hidden" name="si" value="<?php echo $_SERVER['HTTP_HOST'];?>" /><input type="hidden" name="s" value="on" /></form>

</center></div><!--END POST-->

<?php endif; ?>
</div><!--END COL-->
</div><!--END CENTER-->

<div id="left"><!--左侧开始-->
<?php include (TEMPLATEPATH . '/sidebar1.php'); ?>
</div><!--左侧结束-->

<div id="right"><!--右侧开始-->
<?php include (TEMPLATEPATH . '/sidebar2.php'); ?>
</div><!--右侧结束-->

</div><!--END PAGE-->
<?php get_footer(); ?>