<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
<input type="text" name="s" id="s" class="input" value="请输入关键词" onBlur="if(this.value=='') this.value='请输入关键词';" onFocus="if(this.value=='请输入关键词') this.value='';" hechaocheng="1" />
<input name="submit" type="submit" class="button" id="searchsubmit" value="Search" />
</form>
