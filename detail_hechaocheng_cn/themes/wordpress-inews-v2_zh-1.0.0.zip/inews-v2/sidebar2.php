<?php if(is_home()) { ?>
<div class="box"><?php include (TEMPLATEPATH . '/ads200x200.php'); ?></div>
<?php } else { ?>

<div class="list"><h2>最新文章推荐</h2><ul>
<?php get_archives('postbypost', '8', 'custom', '<li>', '</li>'); ?>
</ul></div>
<?php }?>

<div class="list"><h3>最新评论列表</h3><ul>
<?php src_simple_recent_comments(); ?>
</ul></div>

<div class="list"><h3>最受关注的文章</h3><ul>
<?php inews_most_commented(); ?>
</ul></div>

<?php if(!is_page()) { ?>
<div class="list"><?php include (TEMPLATEPATH . '/ads160x600.php'); ?></div>
<?php }?>
