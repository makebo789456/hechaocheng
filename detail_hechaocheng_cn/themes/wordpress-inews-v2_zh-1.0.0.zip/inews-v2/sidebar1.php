<?php if(is_page()) { ?>
<h2>页面导航栏</h2><ul class="pagelist">
<?php wp_list_pages('title_li=&depth=1&sort_column=id' ); ?>
</ul>

<h4>快速搜索栏</h4>
<?php include (TEMPLATEPATH . '/searchform.php'); ?>
<?php } else { ?>

<h4>快速搜索栏</h4>
<?php include (TEMPLATEPATH . '/searchform.php'); ?>

<h2>热门标签排行</h2>
<?php wp_tag_cloud('smallest=12&largest=12&unit=px&number=15&format=list&orderby=count&order=DESC'); ?>

<h3>页面导航栏</h3><ul class="pagelist">
<?php wp_list_pages('title_li=&depth=1&sort_column=id' ); ?>
</ul>

<h3>历史文章索引</h3><ul>
<?php wp_get_archives('type=monthly'); ?>
</ul>
<?php }?>

<h3>友情链接</h3><ul>
<?php get_links(2, '<li>', '</li>', '', TRUE, 'id', FALSE); ?>
</ul>