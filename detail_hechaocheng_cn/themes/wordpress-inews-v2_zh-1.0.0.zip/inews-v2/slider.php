<div id="slide" style="width:240px;height:180px;border:1px solid #e6e6e6;padding:4px">
<div style="width:240px;height:180px;position:relative"><span id="scroll" style="display:none">
<a href="#" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/image/img01.jpg" /></a>
<a href="#" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/image/img02.jpg" /></a>
<a href="#" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/image/img03.jpg" /></a>
<a href="#" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/image/img04.jpg" /></a>
<a href="#" target="_blank"><img src="<?php bloginfo('template_directory'); ?>/image/img05.jpg" /></a>
</span>	
<div style="width:90px;height:16px;position:absolute;top:145px;right:5px"><img src="<?php bloginfo('template_directory'); ?>/image/bian1.gif" id="xiaosan1" width="18" height="14" /><img src="<?php bloginfo('template_directory'); ?>/image/bian1.gif" id="xiaosan2" width="18" height="14" /><img src="<?php bloginfo('template_directory'); ?>/image/bian1.gif" id="xiaosan3" width="18" height="14" /><img src="<?php bloginfo('template_directory'); ?>/image/bian1.gif" id="xiaosan4" width="18" height="14" /><img src="<?php bloginfo('template_directory'); ?>/image/bian1.gif" id="xiaosan5" width="18" height="14" /></div>
<div style="width:90px;height:16px;position:absolute;top:160px;right:5px"><a onmouseover="ove(0)" onmouseout="ou()"><img src="<?php bloginfo('template_directory'); ?>/image/1.gif" width="18" height="14" /></a><a onmouseover="ove(1)" onmouseout="ou()"><img src="<?php bloginfo('template_directory'); ?>/image/2.gif" width="18" height="14" /></a><a onmouseover="ove(2)" onmouseout="ou()"><img src="<?php bloginfo('template_directory'); ?>/image/3.gif" width="18" height="14" /></a><a onmouseover="ove(3)" onmouseout="ou()"><img src="<?php bloginfo('template_directory'); ?>/image/4.gif" width="18" height="14" /></a><a onmouseover="ove(4)" onmouseout="ou()"><img src="<?php bloginfo('template_directory'); ?>/image/5.gif" width="18" height="14" /></a></div>
<div id="show"><a onclick="gotoshow()" onmouseover="tu_ove()" onmouseout="ou()" style="cursor:pointer"><img src="" width="240" height="180" /></a></div>
</div></div>
<script language=JavaScript>
var slideimages=new Array();
var slidelinks=new Array();
var defaultImg = document.getElementById("show").getElementsByTagName("img")[0];
var imgNodes = document.getElementById("scroll").getElementsByTagName("img");
var linkNodes = document.getElementById("scroll").getElementsByTagName("a");
slideimages[0]=imgNodes[0].src;
slideimages[1]=imgNodes[1].src;
slideimages[2]=imgNodes[2].src;
slideimages[3]=imgNodes[3].src;
slideimages[4]=imgNodes[4].src;
slidelinks[0]=linkNodes[0].href;
slidelinks[1]=linkNodes[1].href;
slidelinks[2]=linkNodes[2].href;
slidelinks[3]=linkNodes[3].href;
slidelinks[4]=linkNodes[4].href;
var slidespeed=3000
var slidesanjiaoimages=new Array("<?php bloginfo('template_directory'); ?>/image/bian2.gif","<?php bloginfo('template_directory'); ?>/image/bian1.gif");
var slidesanjiaoimagesname=new Array("xiaosan1","xiaosan2","xiaosan3","xiaosan4","xiaosan5");
var filterArray=new Array();
filterArray[0]="progid:DXImageTransform.Microsoft.Pixelate(enabled=false,duration=2,maxSquare=3)";
filterArray[1]="progid:DXImageTransform.Microsoft.Stretch(duration=1,stretchStyle=PUSH)";
filterArray[2]="progid:DXImageTransform.Microsoft.Stretch(duration=1)";
filterArray[3]="progid:DXImageTransform.Microsoft.Slide(bands=8,duration=1)";
filterArray[4]="progid:DXImageTransform.Microsoft.Fade(duration=1,overlap=0.25)";
var imageholder=new Array()
var ie55=window.createPopup
for (i=0;i<slideimages.length;i++){
imageholder[i]=new Image()
imageholder[i].src=slideimages[i]
}
function tu_ove(){clearTimeout(setID)}
function ou(){slideit()}
var whichlink=0
var whichimage=0
function gotoshow(){
window.open(slidelinks[whichlink]);
}
function slideit(){
defaultImg.style.filter=filterArray[whichimage];
pixeldelay=(ie55)? (defaultImg.filters[0].duration*1000) : 0
if (!document.images) return
if (ie55) {
defaultImg.filters[0].apply();
defaultImg.filters[0].play();
}
defaultImg.src=imageholder[whichimage].src
document.getElementById("xiaosan1").src=slidesanjiaoimages[0];
document.getElementById("xiaosan2").src=slidesanjiaoimages[0];
document.getElementById("xiaosan3").src=slidesanjiaoimages[0];
document.getElementById("xiaosan4").src=slidesanjiaoimages[0];
document.getElementById("xiaosan5").src=slidesanjiaoimages[0];
document.getElementById(slidesanjiaoimagesname[whichimage]).src=slidesanjiaoimages[1];
if (ie55) defaultImg.filters[0].play()
whichlink=whichimage
whichimage=(whichimage<slideimages.length-1)? whichimage+1 : 0
setID=setTimeout("slideit()",slidespeed+pixeldelay)
}
slideit()
function ove(n){
clearTimeout(setID)
whichimage=n;
defaultImg.src=imageholder[whichimage].src
document.getElementById("xiaosan1").src=slidesanjiaoimages[0];
document.getElementById("xiaosan2").src=slidesanjiaoimages[0];
document.getElementById("xiaosan3").src=slidesanjiaoimages[0];
document.getElementById("xiaosan4").src=slidesanjiaoimages[0];
document.getElementById("xiaosan5").src=slidesanjiaoimages[0];
document.getElementById(slidesanjiaoimagesname[whichimage]).src=slidesanjiaoimages[1];
}
</script>
