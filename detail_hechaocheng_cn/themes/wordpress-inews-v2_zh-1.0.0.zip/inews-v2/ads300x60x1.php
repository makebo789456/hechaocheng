<img src="<?php bloginfo('template_directory'); ?>/image/ads300x60.gif" />
